
<p align="center">
  <img src="https://i.ibb.co/9q6VHyL/title.png" />
  <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/b/be/Trie_example.svg/500px-Trie_example.svg.png" />
</p>


# Description

This is an assignment given Ariel university, The purpopse is to read input of words other user.
The program then arranges them in lexicographic order (ascending and descending).

# Implementation

A Trie structure is used in order to implement the solution, each node will keep track of is it a word
and the Trie will support insert word operations. 
The program will recieve input from the user insert the words into the tree and then print them in lexicographic order.

# Files

Trie.c

# Installation

Copy the repository 

```
make trie
```

